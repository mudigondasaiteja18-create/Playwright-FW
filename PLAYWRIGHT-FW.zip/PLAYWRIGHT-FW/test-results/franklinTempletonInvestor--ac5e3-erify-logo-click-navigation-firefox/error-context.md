# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: franklinTempletonInvestor.spec.js >> Franklin Templeton Investor Page Tests >> Verify logo click navigation
- Location: tests\franklinTempletonInvestor.spec.js:50:7

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.waitFor: Test timeout of 30000ms exceeded.
Call log:
  - waiting for locator('a[aria-label*="logo"], img[alt*="Franklin"], [class*="logo"]') to be visible

```

# Test source

```ts
  151 |     }
  152 |   }
  153 | 
  154 |   async uploadFile(locator, filePath, description) {
  155 |     try {
  156 |       await this.waitForElement(locator);
  157 |       if (this.enableHighlight) {
  158 |         await this.highlightElement(locator);
  159 |       }
  160 |       await locator.setInputFiles(filePath);
  161 |       await this.addStepWithScreenshot(description, `upload-${Date.now()}`);
  162 |     } catch (error) {
  163 |       logger.error(`Failed to upload file: ${description}`, error);
  164 |       throw error;
  165 |     }
  166 |   }
  167 | 
  168 |   /**
  169 |    * CHECKBOX METHODS
  170 |    */
  171 | 
  172 |   async check(locator, description) {
  173 |     try {
  174 |       await this.waitForElement(locator);
  175 |       if (this.enableHighlight) {
  176 |         await this.highlightElement(locator);
  177 |       }
  178 |       await locator.check();
  179 |       await this.addStepWithScreenshot(description, `check-${Date.now()}`);
  180 |     } catch (error) {
  181 |       logger.error(`Failed to check: ${description}`, error);
  182 |       throw error;
  183 |     }
  184 |   }
  185 | 
  186 |   async uncheck(locator, description) {
  187 |     try {
  188 |       await this.waitForElement(locator);
  189 |       if (this.enableHighlight) {
  190 |         await this.highlightElement(locator);
  191 |       }
  192 |       await locator.uncheck();
  193 |       await this.addStepWithScreenshot(description, `uncheck-${Date.now()}`);
  194 |     } catch (error) {
  195 |       logger.error(`Failed to uncheck: ${description}`, error);
  196 |       throw error;
  197 |     }
  198 |   }
  199 | 
  200 |   /**
  201 |    * HOVER METHOD
  202 |    */
  203 | 
  204 |   async hover(locator, description) {
  205 |     try {
  206 |       await this.waitForElement(locator);
  207 |       if (this.enableHighlight) {
  208 |         await this.highlightElement(locator);
  209 |       }
  210 |       await locator.hover();
  211 |       await this.addStepWithScreenshot(description, `hover-${Date.now()}`);
  212 |     } catch (error) {
  213 |       logger.error(`Failed to hover: ${description}`, error);
  214 |       throw error;
  215 |     }
  216 |   }
  217 | 
  218 |   /**
  219 |    * ELEMENT GETTER METHODS
  220 |    */
  221 | 
  222 |   async getText(element) {
  223 |     try {
  224 |       const text = await this.page.locator(element).textContent();
  225 |       logger.debug(`Retrieved text: ${text}`);
  226 |       return text;
  227 |     } catch (error) {
  228 |       logger.error(`Failed to get text from element`, error);
  229 |       throw error;
  230 |     }
  231 |   }
  232 | 
  233 |   async getAttribute(element, attributeName) {
  234 |     try {
  235 |       const value = await this.page.locator(element).getAttribute(attributeName);
  236 |       logger.debug(`Retrieved attribute ${attributeName}: ${value}`);
  237 |       return value;
  238 |     } catch (error) {
  239 |       logger.error(`Failed to get attribute ${attributeName}`, error);
  240 |       throw error;
  241 |     }
  242 |   }
  243 | 
  244 |   /**
  245 |    * WAIT METHODS
  246 |    */
  247 | 
  248 |   async waitForElement(selectorOrLocator, description) {
  249 |     const locator = this.getLocator(selectorOrLocator);
  250 |     try {
> 251 |       await locator.waitFor({ state: 'visible', timeout: 30000 });
      |                     ^ Error: locator.waitFor: Test timeout of 30000ms exceeded.
  252 |       logger.info(`✓ Element appeared`);
  253 |       await this.addStepWithScreenshot(`Element appeared`, `wait-element-${Date.now()}`);
  254 |     } catch (error) {
  255 |       logger.error(`Element did not appear`, error);
  256 |       throw error;
  257 |     }
  258 |   }
  259 | 
  260 |   async waitForElementToDisappear(selectorOrLocator, description) {
  261 |     const locator = this.getLocator(selectorOrLocator);
  262 |     try {
  263 |       await locator.waitFor({ state: 'hidden', timeout: 30000 });
  264 |       logger.info(`✓ Element disappeared`);
  265 |       await this.addStepWithScreenshot(`Element disappeared`, `wait-disappear-${Date.now()}`);
  266 |     } catch (error) {
  267 |       logger.error(`Element did not disappear`, error);
  268 |       throw error;
  269 |     }
  270 |   }
  271 | 
  272 |   async waitForNavigation(action, options = {}) {
  273 |     const { timeout = TIMEOUT_CONFIG.LONG } = options;
  274 |     try {
  275 |       await Promise.all([
  276 |         this.page.waitForNavigation({ timeout }),
  277 |         action,
  278 |       ]);
  279 |       logger.info(`✓ Navigation completed`);
  280 |       await this.addStepWithScreenshot(`Navigation completed`, `wait-nav-${Date.now()}`);
  281 |     } catch (error) {
  282 |       logger.error(`Navigation failed`, error);
  283 |       throw error;
  284 |     }
  285 |   }
  286 | 
  287 |   /**
  288 |    * SCROLL METHOD
  289 |    */
  290 | 
  291 |   async scrollIntoView(element) {
  292 |     try {
  293 |       await this.page.locator(element).scrollIntoViewIfNeeded();
  294 |       logger.debug(`Scrolled element into view`);
  295 |     } catch (error) {
  296 |       logger.error(`Failed to scroll element into view`, error);
  297 |       throw error;
  298 |     }
  299 |   }
  300 | 
  301 |   /**
  302 |    * VERIFICATION METHODS
  303 |    */
  304 | 
  305 |   async verifyElementVisible(locator, description) {
  306 |     try {
  307 |       await this.waitForElement(locator);
  308 |       await expect(locator).toBeVisible();
  309 |       logger.info(`✓ ${description}`);
  310 |       await this.addStepWithScreenshot(description, `verify-visible-${Date.now()}`);
  311 |     } catch (error) {
  312 |       logger.error(`Verification failed: ${description}`, error);
  313 |       await AllureReport.attachScreenshot(this.page, `verify-failed-${Date.now()}`);
  314 |       throw error;
  315 |     }
  316 |   }
  317 | 
  318 |   async verifyElementHidden(selectorOrLocator, description) {
  319 |     const locator = this.getLocator(selectorOrLocator);
  320 |     try {
  321 |       await locator.waitFor({ state: 'hidden', timeout: 30000 });
  322 |       logger.info(`✓ ${description}`);
  323 |       await this.addStepWithScreenshot(description, `verify-hidden-${Date.now()}`);
  324 |     } catch (error) {
  325 |       logger.error(`Verification failed: ${description}`, error);
  326 |       await AllureReport.attachScreenshot(this.page, `verify-failed-${Date.now()}`);
  327 |       throw error;
  328 |     }
  329 |   }
  330 | 
  331 |   async verifyElementContainsText(locator, text, description) {
  332 |     try {
  333 |       await this.waitForElement(locator);
  334 |       await expect(locator).toContainText(text);
  335 |       logger.info(`✓ ${description}`);
  336 |       await this.addStepWithScreenshot(description, `verify-text-${Date.now()}`);
  337 |     } catch (error) {
  338 |       logger.error(`Verification failed: ${description}`, error);
  339 |       await AllureReport.attachScreenshot(this.page, `verify-failed-${Date.now()}`);
  340 |       throw error;
  341 |     }
  342 |   }
  343 | 
  344 |   async verifyElementHasAttribute(locator, attributeName, value, description) {
  345 |     try {
  346 |       await this.waitForElement(locator);
  347 |       await expect(locator).toHaveAttribute(attributeName, value);
  348 |       logger.info(`✓ ${description}`);
  349 |       await this.addStepWithScreenshot(description, `verify-attribute-${Date.now()}`);
  350 |     } catch (error) {
  351 |       logger.error(`Verification failed: ${description}`, error);
```